#include <vector>
#include <set>
#include <string>
#include <iostream>
#include "boost/mpl/vector/vector50.hpp"
#include <boost/msm/state_machine.hpp>

using namespace boost::msm;
using namespace std;

namespace  // Concrete FSM implementation
{
    // events
    struct OneSong 
    {
        OneSong(string const& asong):m_Song(asong){}
        const string& get_data() const {return m_Song;}
    private:
        string m_Song;
    };
    template <class DATA>
    struct NotFound
    {
        DATA get_data() const {return m_Data;}
        DATA m_Data;
    };
    template <class DATA>
    struct Found
    {
        DATA get_data() const {return m_Data;}
        DATA m_Data;
    };
    struct Done {};
    // TODO add to a common namespace
    template <class Container,class BASE_TYPE,class FSMType>
    struct Insert : public boost::msm::state<BASE_TYPE,boost::msm::sm_ptr> 
    {
        template <class Event>
        void on_entry(Event const& evt) 
        {
            //TODO other containers
            if (m_Cont)
            {
                m_Cont->insert(evt.get_data());
            }
            m_fsm->process_event(Done());
        }
        void set_sm_ptr(FSMType* fsm){m_fsm=fsm;} 
        void set_container(Container* cont){m_Cont=cont;}
        Container*  m_Cont;

    private:
        FSMType*    m_fsm;
    }; 
    template <class BASE_TYPE,class FSMType>
    struct StringFind : public boost::msm::state<BASE_TYPE,boost::msm::sm_ptr> 
    {  
        template <class Event>
        void on_entry(Event const& evt) 
        {
            //TODO other containers
            // if the element in the event is found
            if (evt.get_data().find(m_Cont) != std::string::npos )
            {
                Found<std::string> res;
                res.m_Data = evt.get_data();
                m_fsm->process_event(res);
            }
            // data not found
            else
            {
                NotFound<std::string> res;
                res.m_Data = evt.get_data();
                m_fsm->process_event(res);
            }
        }
        void set_sm_ptr(FSMType* fsm){m_fsm=fsm;} 
        void set_container(const char* cont){m_Cont=cont;}
    private:
        std::string   m_Cont;
        FSMType*      m_fsm;
    };
    template <class EventType,class Container,class BASE_TYPE,class FSMType>
    struct Foreach : public boost::msm::state<BASE_TYPE,boost::msm::sm_ptr> 
    {
        template <class Event>
        void on_entry(Event const& evt) 
        {
            //TODO other containers
            if (!m_Cont.empty())
            {
                typename Container::value_type next_event = *m_Cont.begin();
                m_Cont.erase(m_Cont.begin());
                m_fsm->process_event(EventType(next_event));
            }
        }
        void set_sm_ptr(FSMType* fsm){m_fsm=fsm;} 
        void set_container(Container* cont){m_Cont=*cont;}

    private:
        Container   m_Cont;
        FSMType*    m_fsm;
    }; 


    // Concrete FSM implementation 
    struct iPodSearch : public state_machine<iPodSearch>
    {
        // The list of FSM states
        typedef std::set<std::string> Songset;
        typedef Insert<Songset,boost::msm::default_base_state,iPodSearch> MyInsert; 
        typedef StringFind<boost::msm::default_base_state,iPodSearch> MyFind;
        typedef Foreach<OneSong,Songset,boost::msm::default_base_state,iPodSearch> MyForeach;

        // the initial state of the player SM. Must be defined
        typedef MyForeach initial_state;

        // transition actions

        // guard conditions

        typedef iPodSearch fsm; // makes transition table cleaner

        // Transition table for player
        struct transition_table : mpl::vector4<
            //     Start       Event              Next         Action				Guard
            //    +-----------+------------------+------------+---------------------+----------------------+
            _row < MyForeach  , OneSong          , MyFind                                                  >,
            _row < MyFind     , NotFound<string> , MyForeach                                               >,
            _row < MyFind     , Found<string>    , MyInsert                                                >,
            _row < MyInsert   , Done             , MyForeach                                               >
            //    +-----------+------------------+------------+---------------------+----------------------+
        > {};
        iPodSearch():m_AllSongs(),m_ResultSearch()
        {
            // add a few songs for testing
            m_AllSongs.insert("Let it be");
            m_AllSongs.insert("Yellow submarine");
            m_AllSongs.insert("Twist and Shout");
            m_AllSongs.insert("She Loves You");
        }
        template <class Event>
        void on_entry(Event const& evt) 
        {
            get_state<MyForeach*>()->set_container(&m_AllSongs);
            get_state<MyInsert*>()->set_container(&m_ResultSearch);
        }
        const Songset& get_result(){return m_ResultSearch;}
        void reset_search(){m_ResultSearch.clear();}

        // Replaces the default no-transition response.
        template <class Event>
        int no_transition(int state, Event const& e)
        {
            std::cout << "no transition from state " << state
                << " on event " << typeid(e).name() << std::endl;
            return state;
        }
    private:
        Songset m_AllSongs;
        Songset m_ResultSearch;
    };

   
    void test()
    {
        iPodSearch search;
        // look for "She Loves You" using the first letters
        search.get_state<iPodSearch::MyFind*>()->set_container("Sh");// will find 2 songs

        // needed to start the highest-level SM. This will call on_entry and mark the start of the SM
        search.start(); 
        // display all the songs
        const iPodSearch::Songset& res = search.get_result();
        for (iPodSearch::Songset::const_iterator it = res.begin();it != res.end();++it)
        {
            cout << "candidate song:" << *it << endl;
        }
        cout << "search using more letters" << endl;
        // look for "She Loves You" using more letters
        search.reset_search();
        search.get_state<iPodSearch::MyFind*>()->set_container("She");// will find 1 song
        search.start(); 
        const iPodSearch::Songset& res2 = search.get_result();
        for (iPodSearch::Songset::const_iterator it = res2.begin();it != res2.end();++it)
        {
            cout << "candidate song:" << *it << endl;
        }

    }
}

int main()
{
    test();
    return 0;
}
