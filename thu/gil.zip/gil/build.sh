export BOOST=/usr/local/include/boost_1_36_0
g++ part1.cpp -I $BOOST -o part1
g++ part2.cpp -I $BOOST -o part2
g++ part3.cpp -I $BOOST -o part3
g++ part4.cpp -I $BOOST -o part4 #requires numeric extenstions
g++ part5.cpp -I $BOOST -o part5
g++ part6.cpp -I $BOOST -o part6
g++ part7.cpp -I $BOOST -o part7

./part1;./part2;./part3;./part4;./part5;./part6;./part7;

#http://stlab.adobe.com/gil/numeric.zip
#g++ part4.cpp -I $BOOST -o part4  
