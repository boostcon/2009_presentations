#include "common.hpp"

template <typename view_t, typename gray_t> inline
double diff_image(view_t v1, view_t v2, gray_t v3)
{
	using namespace boost::gil;
	typedef typename gray_t::value_type pixel_t;

	if (v1.width() != v2.width()) return 1.0;
	if (v2.width() != v3.width()) return 1.0;
	if (v1.height() != v2.height()) return 1.0;
	if (v2.height() != v3.height()) return 1.0;

	float sumdiff = 0;
	for (int y = 0; y < v1.height(); ++y)
	{
		typename view_t::x_iterator itv1 = v1.row_begin(y);
		typename view_t::x_iterator itv2 = v2.row_begin(y);
		typename gray_t::x_iterator itgray = v3.row_begin(y);
		for (int x = 0; x < v1.width(); ++x)
		{
			float r = get_color(itv1[x], red_t()) / 255.0f;
			float g = get_color(itv1[x], green_t()) / 255.0f;
			float b = get_color(itv1[x], blue_t()) / 255.0f;
			float r1 = get_color(itv2[x], red_t()) / 255.0f;
			float g1 = get_color(itv2[x], green_t()) / 255.0f;
			float b1 = get_color(itv2[x], blue_t()) / 255.0f;
			float rd = std::abs(r - r1);
			float gd = std::abs(g - g1);
			float bd = std::abs(b - b1);
			float m = (rd + gd + bd)/3.0f;
			float gr = (1 - m) * 255.0f;
			itgray[x] = pixel_t((int)gr);
			sumdiff += 255.0f - gr;
		}
	}

	return sumdiff / float(255.0 * v1.width() * v1.height());
}

const unsigned char* wad::buffer;

int main()
{
	using namespace boost::gil;
	
	wad wad("wad");

	const unsigned char* buf;
	int w,h,c;
	get_image(Relax,buf,w,h,c);
	rgb8_view_t v = interleaved_view(w,h,(rgb8_pixel_t*)buf,w*c);

	const unsigned char* buf1;
	w,h,c;
	get_image(Relax1,buf1,w,h,c);
	rgb8_view_t v1 = interleaved_view(w,h,(rgb8_pixel_t*)buf1,w*c);

	gray8_image_t img(w,h);
	diff_image(v,v1,view(img));
	
	rgb8_image_t img2(w,h);
	copy_and_convert_pixels(view(img),view(img2));
	
	unsigned char* buffer = interleaved_view_get_raw_data(view(img2));	
	FILE* fd = fopen("part3.ppm","wb");
	fprintf(fd,"P6\n# CREATOR: unknown\n%d %d\n255\n",w,h);
	fwrite(buffer,1,w*h*c,fd);
	fclose(fd);
			
	return 0;
}

