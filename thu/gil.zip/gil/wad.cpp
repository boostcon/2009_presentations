#include <assert.h>
#include <ft2build.h>
#include <util.hpp>
#include <ppm.hpp>
#include <wad.hpp>
#include <wad__.hpp>
 
#include FT_FREETYPE_H
#include FT_GLYPH_H
#include FT_CACHE_H 
 
struct __nps
{
	const char* name;
	const char* path;
	int size;
} 
nps [] = 
{
	{"Epite","/usr/local/fonts/Mini/EPITE___.TTF",12},
	{"Foxley916ExtendedUB","/usr/local/fonts/Mini/FOXL9EUB.TTF",16},
	{"Bullba","/usr/local/fonts/dingbats/BULLBA__.TTF",20},
	{"Capab","/usr/local/fonts/Mini/CAPAB___.TTF",12},	 
	{"Capacity","/usr/local/fonts/Mini/CAPACITY.TTF",12},	 
	{"Capah","/usr/local/fonts/Mini/CAPAH___.TTF",12},	 
	{"Capan","/usr/local/fonts/Mini/CAPAN___.TTF",12},	 
	{"Capat","/usr/local/fonts/Mini/CAPAT___.TTF",12},	 
	{"Capatb","/usr/local/fonts/Mini/CAPATB__.TTF",12},	 
	{"Capaw","/usr/local/fonts/Mini/CAPAW___.TTF",12},	 
	{"Capawb","/usr/local/fonts/Mini/CAPAWB__.TTF",12},	 
	{"Minxb","/usr/local/fonts/Mini/MINXB___.TTF",12},
	{"Minx","/usr/local/fonts/Mini/MINX____.TTF",12},
	{"Minxbrix","/usr/local/fonts/Mini/MINXBRIX.TTF",12},
	{"Minxmono","/usr/local/fonts/Mini/MINXMONO.TTF",12},
	{"Minxt","/usr/local/fonts/Mini/MINXT___.TTF",12},
	{"Minimono","/usr/local/fonts/Mini/MINIMONO.TTF",10},
	{"Monotony","/usr/local/fonts/Mini/MONOTONY.TTF",12},
	{"MonotonyBold","/usr/local/fonts/Mini/MONOB___.TTF",12},
};

struct __npc
{
	const char* name;
	const char* path;
	int channels;
} 
npc [] = 
{
	{"Another","/usr/local/repos/res/a3.ppm",3},
	{"RoundedBorder","/usr/local/repos/res/a10.ppm",3},
	{"SampleGrey","/usr/local/repos/res/a16.ppm",1},
	{"TestImage","/usr/local/repos/res/a1.ppm",3},
	{"ShadedBall","/usr/local/repos/res/a16.ppm",1},
};
 
struct __nb
{
	const char* name;
	const char* buf;
}
nb [] = 
{
	{"hello","this is a hello"},
	{"goodbye","this is a goodbye"},
	{"abc","123456789"},
};

static const char* font_path = "/usr/local/fonts/";
static const char* wad_hpp = "/usr/local/repos/include/wad__.hpp";
static const char* wad_path = "/usr/local/repos/bin/wad";
static const int ascii_count = '~' - ' ' + 1;
static const int fontdef = sizeof(unsigned char)*7 + sizeof(int);
static const int imagedef = sizeof(int)*3;
static const int stringdef = sizeof(int)*2;

static FT_Error face_requester(FTC_FaceID id, FT_Library library, void* data, FT_Face* face)
{
	char** paths = (char**)data;
	char* path = paths[(long)id]; 
	FT_Error error = FT_New_Face(library, path, 0, face);
	if (!error) 
		return 0;

	char npath[255];
	sprintf(npath,"%s/%s",font_path,path);
	return FT_New_Face(library, npath, 0, face);
}

const unsigned char* wad::buffer;

int main(int args, char** argv)
{
	char** fonts = (char**)malloc(sizeof(nps)/sizeof(__nps) * sizeof(char*));

	for (int n = 0; n < sizeof(nps)/sizeof(__nps); ++n)
	{
		fonts[n] = (char*)malloc((strlen(nps[n].path)+1) * sizeof(char));
		sprintf(fonts[n],"%s",nps[n].path);
	}

	FT_Library ftlibrary;
	FT_Init_FreeType(&ftlibrary);

	FTC_Manager ftcmgr;
	FTC_Manager_New(ftlibrary,0,0,0,face_requester,fonts,&ftcmgr);

	FILE* fdh = fopen(wad_hpp,"w");
	FILE* fd = fopen(wad_path,"wb");
	fprintf(fdh, "#ifndef _wad_enums_hpp_\n#define _wad_enums_hpp_\n\n");
	 
	int pos = 0;
	int wadsize = ascii_count * sizeof(nps)/sizeof(__nps) * fontdef; 
	
	fprintf(fdh, "enum __font\n{\n");
	
	int n = 0;
	for (; n < sizeof(nps)/sizeof(__nps); ++n)
	{
		FTC_ScalerRec_ scalerec;
		scalerec.face_id = (FTC_FaceID)n;
		scalerec.width = nps[n].size;
		scalerec.height = nps[n].size;
		scalerec.pixel = 1;
		scalerec.x_res = 0;
		scalerec.y_res = 0; 
 
		FT_Size ftsize;
		if (FTC_Manager_LookupSize(ftcmgr, &scalerec, &ftsize))
		{
			printf("Error: %s\n",nps[n].name);
			continue;
		}
		 
		fprintf(fdh, "\t%s = %d,\n", nps[n].name, pos);
	
		for (char ch = ' '; ch <= '~'; ++ch)
		{
			int load_flags = FT_LOAD_DEFAULT;
			int index = FT_Get_Char_Index(ftsize->face,ch);
			FT_Load_Glyph(ftsize->face, index, load_flags);
			FT_Glyph_Metrics metric = ftsize->face->glyph->metrics;
			int width = ftsize->face->glyph->metrics.width >> 6;
			int height = ftsize->face->glyph->metrics.height >> 6;

			fwrite(&ch,sizeof(unsigned char),1,fd);
			fwrite(&wadsize,sizeof(int),1,fd);
			
			unsigned char val;
			val = metric.horiAdvance >> 6;
			fwrite(&val,sizeof(unsigned char),1,fd);
			
			val = metric.vertAdvance >> 6;
			fwrite(&val,sizeof(unsigned char),1,fd);

			unsigned char bearingY = (unsigned char)(metric.horiBearingY >> 6);
			if (bearingY > height)
				bearingY = height;
			fwrite(&bearingY,sizeof(unsigned char),1,fd);
			
			val = ftsize->face->glyph->advance.x >> 6;
			fwrite(&val,sizeof(unsigned char),1,fd);
			
			fwrite(&width,sizeof(unsigned char),1,fd);
			fwrite(&height,sizeof(unsigned char),1,fd);

			wadsize += width*height;
			pos += fontdef;
		}
	}

	fprintf(fdh, "};\n\n");

	int image_pos = wadsize;	
	
	n = 0;
	for (; n < sizeof(nps)/sizeof(__nps); ++n)
	{
		FTC_ScalerRec_ scalerec;
		scalerec.face_id = (FTC_FaceID)n;
		scalerec.width = nps[n].size;
		scalerec.height = nps[n].size;
		scalerec.pixel = 1;
		scalerec.x_res = 0;
		scalerec.y_res = 0; 
 
		FT_Size ftsize;
		if (FTC_Manager_LookupSize(ftcmgr, &scalerec, &ftsize))
		{
			printf("%s\n",nps[n].name);
			continue;
		}
		 
		for (char ch = ' '; ch <= '~'; ++ch)
		{
			int load_flags = FT_LOAD_DEFAULT;
			int index = FT_Get_Char_Index(ftsize->face,ch);
			FT_Load_Glyph(ftsize->face, index, load_flags);
			FT_Glyph_Metrics metric = ftsize->face->glyph->metrics;

			FT_GlyphSlot glyphslot = ftsize->face->glyph;
			FT_Render_Glyph(glyphslot, FT_RENDER_MODE_NORMAL);
			
			int width = ftsize->face->glyph->metrics.width >> 6;
			int height = ftsize->face->glyph->metrics.height >> 6;

			fwrite(glyphslot->bitmap.buffer,1,width*height,fd);
		}
	}

	for (int n = 0; n < sizeof(nps)/sizeof(__nps); ++n)
		free(fonts[n]);
	
	free(fonts);
	
	FTC_Manager_Done(ftcmgr);
	FT_Done_FreeType(ftlibrary);
	
	fprintf(fdh, "enum static_image\n{\n");

	for (int n = 0; n < sizeof(npc)/sizeof(__npc); ++n)
	{
		int w,h;
		unsigned char* data;
		if (!load_ppm(npc[n].path, data, w, h))
		{
			printf("Error: %s\n",nps[n].name);
			continue;
		}
	
		int c = npc[n].channels;	
		BOOST_ASSERT(c == 1 || c == 3);
		
		fprintf(fdh, "\t%s = %d,\n", npc[n].name, wadsize);

		fwrite(&w,sizeof(int),1,fd);
		fwrite(&h,sizeof(int),1,fd);
		fwrite(&c,sizeof(int),1,fd);
 
		if (c == 1)
		{
			unsigned char data2[w*h];
			for (int m = 0, p=0; m < w*h*3; m+=3, ++p)
				data2[p] = 255-data[m];
			
			fwrite(data2,1,w*h*c,fd);
		}
		else 
		{
			fwrite(data,1,w*h*c,fd);
		}

		wadsize += imagedef + w*h*c;
		free(data);
	}

	fprintf(fdh, "};\n\n");
	
	int string_pos = wadsize;	
	fprintf(fdh, "enum static_string\n{\n");

	for (int n = 0; n < sizeof(nb)/sizeof(__nb); ++n)
	{
		fprintf(fdh, "\t%s = %d,\n", nb[n].name, wadsize);

		int w1 = strlen(nb[n].name);
		int w2 = strlen(nb[n].buf);

		fwrite(&w1,sizeof(int),1,fd);
		fwrite(&w2,sizeof(int),1,fd);

		fwrite(nb[n].name,1,w1,fd);
		fwrite(nb[n].buf,1,w2,fd);
	
		wadsize += stringdef + w1 + w2;
	}
	
	fprintf(fdh, "};\n\n");

	fprintf(fdh, "\n#endif\n");
	fclose(fdh);
	fclose(fd);

	return 0;
}


