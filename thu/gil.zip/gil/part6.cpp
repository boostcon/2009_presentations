#include "common.hpp"

inline double scale(float minv, float maxv, float val)
{
	double result = (maxv-minv) ? ((val-minv)/(maxv-minv)) : 0;
	return 1.0 - result;
}

template <typename panel_t>
struct dual_scaled_bar
{
	const float* data;
	int size,total;
	float minv,maxv;
	dual_scaled_bar(const float* data, int size, float minv, float maxv) :
		data(data), size(size), minv(minv), maxv(maxv), total(0) {}

	template <typename view_t>
	void operator()(const view_t& view)
	{
		BOOST_ASSERT(total++ < size);
		BOOST_ASSERT(maxv >= minv);
		
		int height = view.height();
		BOOST_ASSERT(view.height() >= 0);
		
		float d = *data++;
		if (d == 0) return;
		BOOST_ASSERT(d >= minv);
		BOOST_ASSERT(d <= maxv);

		float v0 = scale(minv,maxv,0);
		float htop = height*v0;
		float hbot = height-htop;

		float y;
		float h;
		
		if (d > 0)
		{
			float vd = scale(0,maxv,d);
			y = round(htop*vd);
			h = htop-y;
		}
		else
		{
			float vd = scale(minv,0,d);
			y = round(htop);
			h = hbot*vd;
		}
		
		panel_t panel;
		panel(subimage_view(view,0,y,view.width(),h));
	}
};

template <typename rgb_t>
struct latitude_lines
{
	const float* data;
	float minv,maxv,pval,diff;
	int size,total,pwidth,pheight;
	latitude_lines(const float* data, int size, float minv, float maxv) :
		data(data), size(size), minv(minv), maxv(maxv), 
			total(0), pwidth(0), pheight(0), pval(0), diff(maxv-minv){}

	template <typename view_t>
	void operator()(const view_t& view)
	{
		BOOST_ASSERT(maxv > minv);
		
		typedef typename view_t::value_type pixel_t;
		pixel_t pixel;
		value_type<rgb_t>(pixel);
		
		static const float u = 0.5;
		float val = *data++;
		
		if (total++ > 0)
		{
			float v0 = (pval - minv) / diff;
			int x0 = pwidth - round(u*(pwidth-1)) - 1;
			int y0 = pheight - round(v0*(pheight-1)) - 1;

			float v1 = (val - minv) / diff;
			int x1 = round(u*(view.width()-1));
			int y1 = view.height() - round(v1*(view.height()-1)) - 1;

			wuline<alpha8_blend>(view,pixel,-x0-1,y0,x1,y1);
		}

		pval = val;
		pwidth = view.width();
		pheight = view.height();
	}
};

inline bool interpolate_extents(float* e, int size, int extent, int margin=0)
{
	float* ehead = e;

	int z = 0;
	int s = 0;
	for (int n = 0; n < size; ++n, ++e)
	{
		if (*e > 0 && *e <= 1)
			*e = (int)((*e) * extent);

		s += (int)(*e);
		z += *e == 0 ? 1 : 0;
	}

	if (z)
	{
		int r = extent + margin - s;
		int b = (int) (r / (float) z);
		int a = r - (z *  b);

		e = ehead;
		for (int n = 0; n < size; ++n, ++e)
		{
			if (*e)
				continue;

			int d = b;
			if (a-- >= 1)
				d++;

			*e = d;
		}
	}
}	

template <typename view_t>
struct longitude_bars
{
	typedef boost::function<void (const view_t&)> vfp_t;
	vfp_t vfp;
	int size;
	longitude_bars(vfp_t vfp, int size) : vfp(vfp), size(size) {}

	void operator()(const view_t& view)
	{
		using namespace boost::gil;

		float extents[size];
		memset(extents,0,sizeof(extents));
		interpolate_extents(extents, size, view.width());
	
		int x = 0;
		for (int n = 0; n < size; ++n)
		{
			int width = (int)extents[n];
			vfp(subimage_view(view,x,0,width,view.height()));
			x += width;
		}
	}
};

void sample6a()
{
	typedef longitude_bars<boost::gil::rgb8_view_t> longbars_t;	
	typedef latitude_lines<black> lines_t;	
	typedef static_layers<fill_t,border_t> panel_t;
	typedef dual_scaled_bar<panel_t> bar_t;

	float data[] = {1,2,3,2,1,-9,-7,-5,-4,-3,1,2,5,7,10,9,7,6,5,3};

	save_image(longbars_t(bar_t(data,20,-9,10),20),
		150,200,"sample6a1.ppm");

	save_image(longbars_t(lines_t(data,20,-9,10),20),
		150,200,"sample6a2.ppm");
}

void sample6b()
{
	typedef longitude_bars<boost::gil::rgb8_view_t> longbars_t;	
	typedef latitude_lines<black> lines_t;	
	typedef static_layers<fill_t,border_t> panel_t;
	typedef dual_scaled_bar<panel_t> bar_t;
	
	#define PI 3.14159265

	float data[360];
	for (int n = 0; n < 360; ++n)
		data[n] = std::cos(n*PI/180.0);

	save_image(longbars_t(lines_t(data,360,-1,1),360),
		200,200,"sample6b1.ppm");

	for (int n = 0; n < 360; ++n)
		data[n] = std::cos(n*PI/180.0);

	save_image(longbars_t(bar_t(data,360,-1,1),360),
		200,200,"sample6b2.ppm");
}

int main()
{
	sample6a();
	sample6b();
	return 0;
}
