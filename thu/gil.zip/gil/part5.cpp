#include "common.hpp"

const unsigned char* wad::buffer;

template <typename color_t, int k = 10>
struct wuline_star
{
	template <typename view_t>
	void operator()(const view_t& view)
	{
		typename view_t::value_type color;
		value_type<color_t>(color);

		int h = view.height()/3;
		int w = view.width()/3;
		int xpos = (view.width()-w)/4.0;
		int ypos = (view.height()-h)/4.0;
		view_t v = subimage_view(view,xpos,ypos,w,h);

		double phase = 0;
		for (double theta = phase; theta < 360 + phase; theta += k)
		{
			int x = (w*cos(theta*3.14/180.0)+w);
			int y = (-h*sin(theta*3.14/180.0)+h);
			wuline<alpha8_blend>(v,color,x,y,w,h);
		}
	}
};

void sample5a()
{
	typedef wuline_star<darkcolor_t> star_t;
	save_image(star_t(),300,300,"sample5a.ppm");
}

int main()
{
	wad w("wad");
	sample5a();
	return 0;
}
