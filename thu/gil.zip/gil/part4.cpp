#include "common.hpp"
#include <boost/gil/extension/numeric/sampler.hpp>
#include <boost/gil/extension/numeric/resample.hpp>

/*
NOTE - ONLY COMPILES IF GIL NUMERIC EXTENSIONS INSTALLED
http://stlab.adobe.com/gil/numeric.zip
*/

const unsigned char* wad::buffer;

using namespace boost::gil;
static const int MAX_MIPS = 100;

template <typename view_t> 
int create_mips(view_t v, view_t* out);

template <typename view_t> 
void destroy_buffers(view_t* v, int size);

template <typename view_t>
inline int get_flatmip_width(view_t* views, int size);

template <typename view_t> inline
void flat_mips(view_t* views, int size, view_t v);

template <typename view_t> inline
void larabee_mips(view_t* views, int size, view_t v);

void sample4a()
{ 
	const unsigned char* data;
	int width,height,channels;
	get_image(Relax,data,width,height,channels);
	boost::gil::rgb8_view_t v = interleaved_view(
		width,height,(boost::gil::rgb8_pixel_t*)data,width*channels);
	
	boost::gil::rgb8_view_t views[MAX_MIPS];
	int n = create_mips(v, views);

	int width2 = get_flatmip_width(views,n);
	int height2 = views[0].height();
	int size = width2*height2*sizeof(boost::gil::rgb8_pixel_t);

	char buffer[size];
	memset(buffer, 255, size);
	boost::gil::rgb8_view_t v2 = interleaved_view(width2,height2,
		(boost::gil::rgb8_pixel_t*)buffer,width2*sizeof(boost::gil::rgb8_pixel_t));

	flat_mips(views,n,v2);

	FILE* fd = fopen("sample4a.ppm","wb");
	fprintf(fd,"P6\n# CREATOR: unknown\n%d %d\n255\n",width2,height2);
	fwrite(buffer,1,size,fd);
	fclose(fd);
}

void sample4b()
{ 
	const unsigned char* data;
	int width,height,channels;
	get_image(Relax,data,width,height,channels);
	boost::gil::rgb8_view_t v = interleaved_view(
		width,height,(boost::gil::rgb8_pixel_t*)data,width*channels);

	rgb8_view_t views[MAX_MIPS];
	int n = create_mips(v, views);

	int width2 = views[0].width() + views[0].width()/2;
	int height2 = views[0].height();
	int size = width2*height2*sizeof(boost::gil::rgb8_pixel_t);
	char buffer[size];
	memset(buffer, 255, size);
	boost::gil::rgb8_view_t v2 = interleaved_view(width2,height2,
		(boost::gil::rgb8_pixel_t*)buffer,width2*sizeof(boost::gil::rgb8_pixel_t));

	larabee_mips(views,n,v2);

	FILE* fd = fopen("sample4b.ppm","wb");
	fprintf(fd,"P6\n# CREATOR: unknown\n%d %d\n255\n",width2,height2);
	fwrite(buffer,1,size,fd);
	fclose(fd);
}

int main()
{
	wad w("wad");
	
	sample4a();
	sample4b();
	return 0;
}

template <typename view_t> inline
int create_mips(view_t v, view_t* out)
{
	using namespace boost::gil;
	typedef typename view_t::value_type pixel_t;

	int mips = 0;
	while (std::max(v.width() >> mips, 1) != 1 &&
		std::max(v.height() >> mips, 1) != 1) mips++;

	out[0] = v;

	for ( int n=1; n <= mips; n++ )
	{
		int cw = v.width() >> n;
		int ch = v.height() >> n;
		unsigned char* buffer = (unsigned char*)malloc(cw*ch*sizeof(pixel_t));
		out[n] = interleaved_view(cw,ch,(pixel_t*)buffer,cw*sizeof(pixel_t));
		resize_view(out[n-1], out[n], boost::gil::bilinear_sampler());
	}

	return mips+1;
}

template <typename view_t> inline
void destroy_buffers(view_t* v, int size)
{
	using namespace boost::gil;
	typedef typename view_t::value_type pixel_t;	

	for (int n=0; n < size; n++ )
	{
		unsigned char* buffer = interleaved_view_get_raw_data(v[n]);
		free(buffer);
	}
}

template <typename view_t>
inline int get_flatmip_width(view_t* views, int size)
{
	int width = views[0].width();
	for ( int n=1; n < size; n++ )
		width += views[0].width() >> n;
	return width;
}

template <typename view_t> inline
void flat_mips(view_t* views, int size, view_t v)
{
	using namespace boost::gil;

	int x = 0;
	for ( int n=0; n < size; n++ )
	{
		int xx = views[n].width();
		int yy = views[n].height();
		view_t v2 = subimage_view(v,x,0,xx,yy);
		copy_and_convert_pixels(views[n],v2);
		x += xx;
	}
}; 

template <typename view_t> inline
void larabee_mips(view_t* views, int size, view_t v)
{
	using namespace boost::gil;

	view_t v2 = subimage_view(v,0,0,views[0].width(),views[0].height());
	copy_and_convert_pixels(views[0],v2);

	int y = 0;
	int x = views[0].width();
	for ( int n=1; n < size; n++ )
	{
		int xx = views[n].width();
		int yy = views[n].height();
		v2 = subimage_view(v,x,y,xx,yy);
		copy_and_convert_pixels(views[n],v2);
		y += yy;
	}
}

