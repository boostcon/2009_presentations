// Copyright (c) 2008-2009 Tom Brinkman (tombrinkman@reportbase.com)
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

/**
 * @file blend.hpp
 * @brief blenders
 * @author Tom Brinkman
 */
 
// $Id: blend.hpp 39 2009-02-16 23:02:14Z reportbase $

#ifndef _blend_hpp_
#define _blend_hpp_

#include <boost/gil/gil_all.hpp>
#include <boost/function.hpp>

/**
   @brief default - no blending
 */

struct null_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		dst = src;
	}
};

/**
   @brief lightens - maximum value
 */

 struct lighten_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		dst = (std::max)(dst,src);
	}
};

/**
   @brief darkens - minimum value
 */

 struct darken_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		dst = (std::min)(dst,src);
	}
};

/**
   @brief multiplies - (r1 * r2) / 255
 */

struct scaled_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		dst = (dst * src) / 255;
	}
};

/**
   @brief averages - (r1 + r2) / 2
 */

struct median_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		dst = (dst + src) / 2.0;
	}
};

/**
   @brief adds - (r1 + r2)
 */

struct accumulated_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		dst = (std::max)(255, dst + src);
	}
};

/**
   @brief subtracts - (r1 + r2 - 255)
 */

struct subtracted_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		dst = ((dst + src) < 255) ? 0 : (dst + src - 255);
	}
};

/**
   @brief difference - (r1 - r2)
 */

struct absolute_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		dst = (std::abs)(dst - src);
	}
};

/**
   @brief negation - (255-r1-r2)
 */

struct negated_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		dst = 255 - (std::abs)(255-dst-src);
	}
};

/**
   @brief screen - (255 - (((255 - r1) * (255 - r2)) >> 8))
 */

struct screen_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		dst = 255 - (((255 - dst) * (255 - src)) >> 8);
	}
};

/**
   @brief exclusion - (r1 + r2 - 2 * r1 * r2 / 255)
 */

struct exclusive_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		dst = (dst + src - 2 * dst * src / 255);
	}
};

/**
   @brief overlay
 */

struct overlayed_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		dst = (src < 128) ? (2 * dst * src / 255) :
			(255 - 2 * (255 - dst) * (255 - src) / 255);
	}
};

/**
   @brief softlight
 */

struct softlight_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		dst = (src < 128) ? (2*((dst >> 1)+64)) * (src/255) :
			(255 - (2*(255-((dst >> 1) + 64))*(255-src)/255));
	}
};

/**
   @brief hardlight
 */

struct hardlight_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		overlayed_blender bo;
		T dstext_e = dst;
		T src2 = src;
		bo(src2,dstext_e);
		dst = src2;
	}
};

/**
   @brief colordodge
 */

struct colordodge_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		dst = (dst == 255) ? dst : (std::min)(255, ((src << 8 ) / (255 - dst)));
	}
};

/**
   @brief colorburn
 */

struct colorburn_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		dst = (dst == 0) ? dst : (std::max)(0, (255 - ((255 - src) << 8 ) / dst));
	}
};

/**
   @brief lineardodge
 */

struct lineardodge_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		accumulated_blender ba;
		ba(dst,src);
	}
};

/**
   @brief linearburn
 */

struct linearburn_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		subtracted_blender ba;
		ba(dst,src);
	}
};

/**
   @brief linearlight
 */

struct linearlight_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		if (dst < 128)
		{
			T dstext_e = dst*2;
			colorburn_blender lb;
			lb(dstext_e,src);
			dst = dstext_e;
		}
		else
		{
			T dstext_e = 2 * (dst - 128);
			colordodge_blender ld;
			ld(dstext_e,src);
			dst = dstext_e;
		}
	}
};

/**
   @brief vividlight
 */

struct vividlight_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		if (dst < 128)
		{
			T dstext_e = dst*2;
			colorburn_blender cb;
			cb(dstext_e,src);
			dst = dstext_e;
		}
		else
		{
			T dstext_e = 2 * (dst - 128);
			colordodge_blender cd;
			cd(dstext_e,src);
			dst = dstext_e;
		}
	}
};

/**
   @brief pinlight
 */

struct pinlight_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		if (dst < 128)
		{
			T dstext_e = 2 * dst;
			darken_blender bd;
			bd(dstext_e,src);
			dst = dstext_e;
		}
		else
		{
			T dstext_e = (2 *(dst - 128));
			lighten_blender ld;
			ld(dstext_e,src);
			dst = dstext_e;
		}
	}
};

/**
   @brief hardmix
 */

struct hardmax_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		dst = (dst < 255 - src) ? 0:255;
	}
};

/**
   @brief reflect
 */

struct reflected_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		dst = (src == 255) ? src : (std::min)(255, (dst * dst / (255 - src)));
	}
};

/**
   @brief glow
 */

struct glow_blender
{
	template <typename T>
	void operator()(T& dst, T& src)
	{
		reflected_blender r;
		T dstext_e = dst;
		T src2 = src;
		r(src2,dstext_e);
		dst = src2;
	}
};

/**
   @brief phoenix
 */

struct phoenix_blender 
{

	template <typename T>
	void operator()(T& dst, T& src)
	{
		dst = (std::min)(dst,src) - (std::max)(dst,src) + 255;
	}
};

#endif
