#include "common.hpp"

const unsigned char* wad::buffer;

typedef boost::gil::rgb8_view_t view_t;
typedef boost::function<void (view_t&)> funct_t;

struct glyph
{
	char ch;
	int horiAdvance;
	int vertAdvance;
	int bearingY;
	int advanceX;
	int width;
	int height;
	const unsigned char* buffer;
};

template <__font pos>
struct static_glyph
{
	static const short defsize = sizeof(unsigned char)*7 + sizeof(int);
	
	glyph operator()(char ch)
	{
		int p = (ch - ' ') * defsize;
		const unsigned char* w = wad::buffer+(pos+p);
		assert(ch == w[0]);
		int a = ((w[1] | w[2] << 8) | w[3] << 16) | w[4] << 24;
		
		glyph g;
		g.ch = w[0];
		g.buffer = wad::buffer+a;
		g.horiAdvance = (int)(w[5]);
		g.vertAdvance = (int)(w[6]);
		g.bearingY = (int)(w[7]);
		g.advanceX = (int)(w[8]);
		g.width = (int)(w[9]);
		g.height = (int)(w[10]);
		return g;
	}
};

template <typename view_t>
struct blend_gray
{
	typedef typename view_t::value_type pixel_t;
	pixel_t pixel;
	boost::gil::gray8c_view_t  gray;
	blend_gray(boost::gil::gray8c_view_t gray, pixel_t pixel) : 
		gray(gray), pixel(pixel) {}

	void operator()(const view_t& view)
	{
		using namespace boost::gil;
		int w = std::min(view.width(), gray.width());
		int h = std::min(view.height(), gray.height());

		for (int y = 0; y < h; ++y)
		{
			typename view_t::x_iterator itv = view.row_begin(y);
			typename gray8c_view_t::x_iterator itg = gray.row_begin(y);
			for (int x = 0; x < w; ++x)
			{
				pixel_t dst = pixel;
				static_for_each(dst, itv[x], alpha8_blend(itg[x]));
				itv[x] = dst;
			}
		}
	}
};

struct make_width
{
	int n;
	int advance;
	make_width() : n(0), advance(0) {}
	operator int(){return n;}
	
	template <typename T>
	void operator()(T t)
	{
		advance += t.horiAdvance;
		n = advance - (t.horiAdvance - t.width);
	}
};

struct make_height
{
	int n;
	make_height() : n(0){}
	operator int(){return n;}
	
	template <typename T>
	void operator()(T t)
	{
		n = (std::max)(t.height,n);
	}
};

struct make_max_width
{
	int n;
	make_max_width() : n(0) {}
	operator int(){return n;}

	template <typename T>
	void operator()(T t)
	{
		n = (std::max)(t.width, n);
	}
};

struct glyph_height
{
	int n;
	glyph_height() : n(0) {}
	operator int(){return n;}

	template <typename T>
	void operator()(T t)
	{
		n = (std::max)(n,t.height-t.bearingY);
	}
};

struct find_last_fitted_glyph
{
	int width,x;
	find_last_fitted_glyph(int width) : width(width),x(0){}
		
	template <typename T>
	bool operator()(T t)
	{
		int tmp = x + t.width;
		x += t.horiAdvance; 
		return tmp > width;
	}
};

template <static_image img, typename rgb_t>
struct static_blend
{
	template <typename view_t>
	void operator()(const view_t& view)
	{
		using namespace boost::gil;
		
		typedef typename view_t::value_type pixel_t;
		pixel_t pixel;
		value_type<rgb_t>(pixel);
		
		const unsigned char* buf;
		int w,h,c;
		get_image(img,buf,w,h,c);
		
		gray8c_view_t gray = interleaved_view(w,h,(gray8_pixel_t*)buf,w);

		int xpos = (view.width()-w)/2.0;
		int ypos = (view.height()-h)/2.0;
		view_t v = subimage_view(view,xpos,ypos,w,h);
		
		for (int y = 0; y < h; ++y)
		{
			typename view_t::x_iterator itv = v.row_begin(y);
			typename gray8c_view_t::x_iterator itg = gray.row_begin(y);
			for (int x = 0; x < w; ++x)
			{
				pixel_t dst = pixel;
				static_for_each(dst, itv[x], alpha8_blend(itg[x]));
				itv[x] = dst;
			}
		}
	}
};

template <typename view_t>
struct advance_x
{
	typedef typename view_t::value_type pixel_t;
	int x;
	pixel_t pixel;
	const view_t& v;
	advance_x(const view_t& v, pixel_t pixel) : v(v), x(0), pixel(pixel) {}	

	template <typename T>
	void operator()(T& t)
	{
		using namespace boost::gil;

		int h = v.height();
		int y = h - t.bearingY;
		int width = t.width;
		int height = t.height;
		int xadvance = t.advanceX;

		gray8c_view_t gv = interleaved_view(width,height,
			(gray8_pixel_t*)t.buffer,width);

		blend_gray<view_t> blend(gv,pixel);
		blend(subimage_view(v,x,y,width,height));
		
		x += xadvance; 
	}
};

template <typename font_t, typename rgb_t>
struct textal
{
	typedef boost::gil::point2<float> point_t;
	point_t pt;
	const char* str;
	int align;

	textal(const char* str, point_t pt = point_t(0.5,0.5), int align = center|middle) :
		str(str), align(align), pt(pt)
	{
		BOOST_ASSERT(pt.x >= 0);
		BOOST_ASSERT(pt.y >= 0);
		BOOST_ASSERT(pt.x <= 1);
		BOOST_ASSERT(pt.y <= 1);
	}

	template <typename view_t>
	void operator()(const view_t& view)
	{
		typedef typename view_t::value_type pixel_t;
		pixel_t pixel;
		value_type<rgb_t>(pixel);
		
		int h = view.height();
		int w = view.width();
		int x = (int)(pt.x*(w-1));
		int y = (int)(pt.y*(h-1));

		glyph m[1000];
		std::transform(str,str+strlen(str),m,font_t());

		glyph* itm = std::find_if(m,m+strlen(str),find_last_fitted_glyph(w-x));
		int mwidth = std::for_each(m,itm,make_width());	
		int mheight = std::for_each(m,itm,make_height());	
		int gheight = std::for_each(m,itm,glyph_height());	
		
		if (align & right)
			x -= mwidth;
		else if (align & center)
			x -= mwidth/2;
		
		if (align & bottom)
			y -= mheight;
		else if (align & middle)
			y -= mheight/2;

		std::for_each(m, itm, advance_x<view_t>(
			subimage_view(view,x,y,mwidth,mheight), pixel));
	}
};

typedef static_blend<ShadedBall, red> redball_t;
typedef static_blend<ShadedBall, blue> blueball_t;
typedef static_blend<ShadedBall, green> greenball_t;
typedef static_layers<fill_t,border_t> basiclayer_t;
typedef static_layers<fill_t,border_t,redball_t> redball_layer_t;
typedef static_layers<fill_t,border_t,blueball_t> blueball_layer_t;
typedef static_layers<fill_t,border_t,greenball_t> greenball_layer_t;
typedef textal<static_glyph<Monotony>,darkcolor_t> textal_t;

template <typename layer_t>
struct text_layer
{
	const char* str;
	text_layer(const char* str) : str(str) {}

	template <typename view_t>
	void operator()(view_t view)
	{
		layer_t lay;
		lay(view);
		
		textal_t txt(str);
		txt(view);
	}
};

void sample7a()
{
	std::map<std::string,funct_t> lst;
	lst["red"] = text_layer<redball_layer_t>("RED BALL");
	lst["green"] = text_layer<greenball_layer_t>("GREEN BALL");
	lst["blue"] = text_layer<blueball_layer_t>("BLUE BALL");

	std::map<std::string,funct_t>::iterator it = lst.find("red");
	funct_t funct = it->second;

	char path[255];
	sprintf(path,"sample7a.ppm");
	save_image(funct,150,150,path);	
}

void sample7b()
{
	text_layer<redball_layer_t> a("RED BALL");
	text_layer<blueball_layer_t> b("BLUE BALL");
	text_layer<greenball_layer_t> c("GREEN BALL");
	
	std::vector<funct_t> lst;
	lst.push_back(a);
	lst.push_back(b);
	lst.push_back(c);
	
	for (int n = 0; n < lst.size(); ++n) 
	{
		funct_t funct = lst[n];

		char path[255];
		sprintf(path,"sample7b.%d.ppm",n);
		save_image(funct,150,150,path);	
	}
}

int main()
{
	wad w("wad");
	
	sample7a();
	sample7b();
	return 0;
}
