#include "common.hpp"
#include "blend.hpp"

template <typename view_t, typename blend_t>
struct blend
{
	view_t b;
	blend(const view_t b) : b(b) {}
		
	void operator()(const view_t& a)
	{
		using namespace boost::gil;
		typedef typename view_t::value_type pixel_t;
		int w = std::min(a.width(),b.width());
		int h = std::min(a.height(),b.height());
		
		for (int y = 0; y < h; ++y)
		{
			typename view_t::x_iterator ita = a.row_begin(y);
			typename view_t::x_iterator itb = b.row_begin(y);
			for (int x = 0; x < w; ++x)
			{
				pixel_t dst = ita[x];
				boost::gil::static_for_each(dst, itb[x], blend_t());
				ita[x] = dst;
			}
		}
	}
};

template <typename blend_t>
void blender(const char* path)
{
	using namespace boost::gil;
	
	const unsigned char* buf_;
	int w,h,c;
	get_image(Palmtree,buf_,w,h,c);
	int size = w*h*c;
	unsigned char* buf = (unsigned char*)malloc(size);
	memcpy(buf,buf_,size);
	rgb8_view_t v = interleaved_view(w,h,(rgb8_pixel_t*)buf,w*c);

	const unsigned char* buf2_;
	get_image(Relax,buf2_,w,h,c);
	size = w*h*c;
	unsigned char* buf2 = (unsigned char*)malloc(size);
	memcpy(buf2,buf2_,size);
	rgb8_view_t v2 = interleaved_view(w,h,(rgb8_pixel_t*)buf2,w*c);

	blend<rgb8_view_t,blend_t> b(v);
	b(v2);

	FILE* fd = fopen(path,"wb");
	fprintf(fd,"P6\n# CREATOR: unknown\n%d %d\n255\n",w,h);
	fwrite(buf2,1,w*h*c,fd);
	fclose(fd);
	
	free(buf);
	free(buf2);
}

const unsigned char* wad::buffer;

int main()
{
	wad w("wad");
	
	blender<lighten_blender>("lighten_blender.ppm");
	blender<darken_blender>("darken_blender.ppm");
	blender<scaled_blender>("scaled_blender.ppm");
	blender<median_blender>("median_blender.ppm");
	blender<accumulated_blender>("accumulated_blender.ppm");
	blender<subtracted_blender>("subtracted_blender.ppm");
	blender<absolute_blender>("absolute_blender.ppm");
	blender<negated_blender>("negated_blender.ppm");
	blender<screen_blender>("screen_blender.ppm");
	blender<exclusive_blender>("exclusive_blender.ppm");
	blender<overlayed_blender>("overlayed_blender.ppm");
	blender<softlight_blender>("softlight_blender.ppm");
	blender<hardlight_blender>("hardlight_blender.ppm");
	blender<colordodge_blender>("colordodge_blender.ppm");
	blender<colorburn_blender>("colorburn_blender.ppm");
	blender<lineardodge_blender>("lineardodge_blender.ppm");
	blender<linearburn_blender>("linearburn_blender.ppm");
	blender<linearlight_blender>("linearlight_blender.ppm");
	blender<vividlight_blender>("vividlight_blender.ppm");
	blender<reflected_blender>("reflected_blender.ppm");
	blender<glow_blender>("glow_blender.ppm");
	blender<phoenix_blender>("phoenix_blender.ppm");
	blender<pinlight_blender>("pinlight_blender.ppm");
	return 0;
}

