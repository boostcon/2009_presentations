// Copyright (c) 2008-2009 Tom Brinkman (tombrinkman@reportbase.com)
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef _boostcon09_hpp_
#define _boostcon09_hpp_

#include <assert.h>
#include <string>
#include <vector>
#include <map>
#include <boost/gil/gil_all.hpp>
#include <boost/function.hpp>

enum
{
	left = (0x1 << 1), 		
	center = (0x1 << 2), 	
	right = (0x1 << 3), 		
	top = (0x1 << 4), 		
	middle = (0x1 << 5),  	
	fmiddle = (0x1 << 7), 	
	bottom = (0x1 << 8),
};

enum __font
{
	Monotony = 17765,
};

enum static_image
{
	ShadedBall = 371069,
	Palmtree = 386089,
	Relax = 861913,
	Relax1 = 1099825,
};

enum static_string
{
	hello = 1337737,
	goodbye = 1337765,
	abc = 1337797,
};

template <char r, char g, char b>
struct rgb
{
	static const char red = r;
	static const char green = g;
	static const char blue = b;
};

template <typename rgb_t> inline
void value_type(boost::gil::rgb8_view_t::value_type& pixel)
{
	typedef boost::gil::rgb8_view_t::value_type pixel_t;
	pixel = pixel_t(rgb_t::red, rgb_t::green, rgb_t::blue);
}

struct null_functor
{
	template <typename type_t>
	void operator()(type_t&){}
};

template <typename type_t>
struct is
{
	static const int valid = true;
};

template<>
struct is<null_functor> {static const int valid = false;};

template <
	typename layer1_t, 
	typename layer2_t, 
	typename layer3_t = null_functor,
	typename layer4_t = null_functor,
	typename layer5_t = null_functor>
struct static_layers
{
	template <typename view_t>
	void operator()(const view_t& view)
	{
		layer1_t()(view);
		layer2_t()(view);

		if (is<layer3_t>::valid)
			layer3_t()(view);
		if (is<layer4_t>::valid)
			layer4_t()(view);
		if (is<layer5_t>::valid)
			layer5_t()(view);
	}
};

template <typename color_t>
struct fill
{
	template <typename view_t>
	void operator()(const view_t& view)
	{
		typedef typename view_t::value_type pixel_t;
		
		pixel_t pixel;
		value_type<color_t>(pixel);

		for (int y = 0; y < view.height(); ++y)
		{
			typename view_t::x_iterator it = view.row_begin(y);
			for (int x = 0; x < view.width(); ++x)
			{
				it[x] = pixel;
			}
		}
	}
};

template <typename strong_t, typename weak_t>
struct border
{
	template <typename view_t>
	void operator()(const view_t& view)
	{
		typedef typename view_t::value_type pixel_t;

		pixel_t strong,weak;
		value_type<strong_t>(strong);
		value_type<weak_t>(weak);
		
		for (int y = 0; y < view.height(); ++y)
		{
			view(0,y) = weak;
			view(view.width()-1,y) = strong;
		}

		for (int x = 0; x < view.width(); ++x)
		{
			view(x,0) = weak;
			view(x,view.height()-1) = strong;
		}
	}
};

struct wad
{
	static const unsigned char* buffer;

	wad(const char* path)
	{
		FILE* fd = fopen(path,"rb");
		BOOST_ASSERT(fd);
		if (fd)
		{
			static const int size = 500;
			buffer = (unsigned char*)malloc(size);

			int pos = 0;
			std::size_t len = 0;
			while (!feof(fd))
			{
				char buf[size];
				int len = fread ((void *)buf, 1, size, fd);
				buffer = (unsigned char*) realloc((void *)buffer,pos+len);
				memcpy((unsigned char*)buffer+pos,buf,len);
				pos += len;	    
			}
		
			fclose(fd);
		}
	}

	~wad()
	{
		free((void*)buffer);
	}
};

struct alpha8_blend
{
	int alpha;	
	alpha8_blend(int alpha) : alpha(alpha){}

	template <typename T>
	void operator()(T& dst, const T src)
	{
		dst = ((dst + 1) * alpha >> 8) - ((src + 1) * alpha >> 8) + src;
	}
};

inline void get_image(static_image p, const unsigned char*& buffer, int& width, int& height, int& channels)
{
	const unsigned char* w = wad::buffer+p;
	width = ((w[0] | w[1] << 8) | w[2] << 16) | w[3] << 24;
	height = ((w[4] | w[5] << 8) | w[6] << 16) | w[7] << 24;
	channels = ((w[8] | w[9] << 8) | w[10] << 16) | w[11] << 24;
	buffer = w + 12;
}

inline void get_string(static_string p, const unsigned char*& buffer, int& size)
{
	const unsigned char* w = wad::buffer+p;
	int w1 = ((w[0] | w[1] << 8) | w[2] << 16) | w[3] << 24;
	int w2= ((w[4] | w[5] << 8) | w[6] << 16) | w[7] << 24;
	buffer = w+w1+sizeof(int)*2;
	size = w2;
}

template <typename funct_t>
void save_image(funct_t funct, int width, int height, const char* path)
{
	int channels = 3;
	int size = width * height * channels;
	unsigned char* buffer = (unsigned char*)malloc(size);
	memset(buffer,150,size);
	
	boost::gil::rgb8_view_t view = 
		boost::gil::interleaved_view(width,height,
			(boost::gil::rgb8_pixel_t*)buffer,width*channels);
	
	funct(view);

	FILE* fd = fopen(path,"wb");
	fprintf(fd,"P6\n# CREATOR: unknown\n%d %d\n255\n",width,height);
	fwrite(buffer,1,size,fd);

	fclose(fd);
	free(buffer);			
}


template <typename blend_t, typename view_t> inline
void wuline(const view_t& view, typename view_t::value_type pixel, int x0, int y0, int x1, int y1)
{
	using namespace boost::gil;
	static const int NumLevels=256;
	static const int IntensityBits=8;

	unsigned short IntensityShift, ErrorAdj, ErrorAcc;
	unsigned short ErrorAccTemp, Weighting, WeightingComplementMask;
	short DeltaX, DeltaY, Temp, XDir;

	if (y0 > y1)
	{
  		Temp = y0; y0 = y1; y1 = Temp;
  		Temp = x0; x0 = x1; x1 = Temp;
	}

	view(x0,y0) = pixel;

	if ((DeltaX = x1 - x0) >= 0)
	{
  		XDir = 1;
	} 
	else 
	{
		XDir = -1;
		DeltaX = -DeltaX; 
	}

	if ((DeltaY = y1 - y0) == 0)
	{
  		while (DeltaX-- != 0) 
		{
			x0 += XDir;
			view(x0,y0) = pixel;
  		}
      		
		return;
	}
	
	if (DeltaX == 0) 
	{
		do 
		{
			y0++;
			view(x0,y0) = pixel;
		} 
		while (--DeltaY != 0);

		return;
	}

	if (DeltaX == DeltaY) 
	{
		do 
		{
			x0 += XDir;
			y0++;
			view(x0,y0) = pixel;
		} 
		while (--DeltaY != 0);

		return;
	}

	ErrorAcc = 0;  
	IntensityShift = 16 - IntensityBits;
	WeightingComplementMask = NumLevels - 1;

	if (DeltaY > DeltaX) 
	{
		ErrorAdj = ((unsigned long) DeltaX << 16) / (unsigned long) DeltaY;

		while (--DeltaY) 
		{
			ErrorAccTemp = ErrorAcc;   
			ErrorAcc += ErrorAdj;     
         	
			if (ErrorAcc <= ErrorAccTemp) 
				x0 += XDir;
         		
			y0++;

			Weighting = ErrorAcc >> IntensityShift;
	
			typename view_t::value_type dst = pixel;
			static_for_each(dst,view(x0,y0), blend_t((Weighting ^ WeightingComplementMask)));
			view(x0,y0) = dst;

			dst = pixel;
			static_for_each(dst,view(x0 + XDir, y0), blend_t(Weighting));
			view(x0 + XDir, y0) = dst;
  		}

		view(x1,y1) = pixel;
		return;
	}

	ErrorAdj = ((unsigned long) DeltaY << 16) / (unsigned long) DeltaX;

	while (--DeltaX) 
	{
		ErrorAccTemp = ErrorAcc;   
		ErrorAcc += ErrorAdj;     
      		
		if (ErrorAcc <= ErrorAccTemp) 
			y0++;

		x0 += XDir;
      		
		Weighting = ErrorAcc >> IntensityShift;

		typename view_t::value_type dst = pixel;
		static_for_each(dst,view(x0,y0), blend_t(Weighting ^ WeightingComplementMask));
		view(x0,y0) = dst;
	
		dst = pixel;
		static_for_each(dst,view(x0, y0 + 1), blend_t(Weighting));
		view(x0, y0 + 1) = dst;
	}

	view(x1,y1) = pixel;
}

typedef rgb<180,180,110> color_t;
typedef rgb<10,10,10> darkcolor_t;
typedef rgb<230,230,230> lightcolor_t;
typedef rgb<255,0,0> red;
typedef rgb<0,0,255> blue;
typedef rgb<0,255,0> green;
typedef rgb<0,0,0> black;
typedef fill<color_t> fill_t;
typedef border<darkcolor_t,lightcolor_t> border_t;


#endif
