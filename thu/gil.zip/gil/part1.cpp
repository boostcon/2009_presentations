#include "common.hpp"

void sample1a()
{ 
	int width = 2;
	int height = 2;
	int channels = 3;
	int size = sizeof(unsigned char)*width*height*channels;
	unsigned char* buffer = (unsigned char*)malloc(size);
	unsigned char* head = buffer;

	for (int y = 0; y < height; ++y)
	{
		for (int x = 0; x < width; ++x)
		{
			*buffer++ = 0;
			*buffer++ = 0;
			*buffer++ = 255;
		}
	}

	buffer = head;

	FILE* fd = fopen("sample1a.ppm","wb");
	fprintf(fd,"P6\n# CREATOR: unknown\n%d %d\n255\n",width,height);
	fwrite(buffer,1,size,fd);
	fclose(fd);
	free(buffer);
}

void sample2a(unsigned char* buffer, int width, int height)
{
	for (int y = 0; y < height; ++y)
	{
		for (int x = 0; x < width; ++x)
		{
			*buffer++ = 0;
			*buffer++ = 0;
			*buffer++ = 255;
		}
	}
}

void sample2a()
{
	int width = 2;
	int height = 2;
	int channels = 3;
	int size = sizeof(unsigned char)*width*height*channels;
	unsigned char* buffer = (unsigned char*)malloc(size);

	sample2a(buffer,2,2);

	FILE* fd = fopen("sample2a.ppm","wb");
	fprintf(fd,"P6\n# CREATOR: unknown\n%d %d\n255\n",width,height);
	fwrite(buffer,1,size,fd);
	fclose(fd);
	free(buffer);
}

void sample3a(unsigned char* buffer, int width, int height, char red, char green, char blue)
{
	for (int y = 0; y < height; ++y)
	{
		for (int x = 0; x < width; ++x)
		{
			*buffer++ = red;
			*buffer++ = green;
			*buffer++ = blue;
		}
	}
}

void sample3a()
{
	int width = 2;
	int height = 2;
	int channels = 3;
	int size = sizeof(unsigned char)*width*height*channels;
	unsigned char* buffer = (unsigned char*)malloc(size);

	sample3a(buffer,2,2,0,0,255);

	FILE* fd = fopen("sample3a.ppm","wb");
	fprintf(fd,"P6\n# CREATOR: unknown\n%d %d\n255\n",width,height);
	fwrite(buffer,1,size,fd);
	fclose(fd);
	free(buffer);
}

void sample4a(unsigned char* buffer, int width, int height, char red, char green, char blue, char alpha)
{
	for (int y = 0; y < height; ++y)
	{
		for (int x = 0; x < width; ++x)
		{
			*buffer++ = red;
			*buffer++ = green;
			*buffer++ = blue;
			*buffer++ = alpha;
		}
	}
}

void sample4a()
{
	int width = 2;
	int height = 2;
	int channels = 4;
	int size = sizeof(unsigned char)*width*height*channels;
	unsigned char* buffer = (unsigned char*)malloc(size);

	sample4a(buffer,2,2,0,0,255,0);

	FILE* fd = fopen("sample4a.ppm","wb");
	fprintf(fd,"P6\n# CREATOR: unknown\n%d %d\n255\n",width,height);
	fwrite(buffer,1,size,fd);
	fclose(fd);
	free(buffer);
}

void sample5a(unsigned char* buffer, int width, int height, int channels, char value)
{
	for (int y = 0; y < height; ++y)
	{
		for (int x = 0; x < width; ++x)
		{
			for (int c = 0; c < channels; ++c)
			{
				*buffer++ = value;
			}
		}
	}
}

void sample5a()
{
	int width = 2;
	int height = 2;
	int channels = 3;
	int size = sizeof(unsigned char)*width*height*channels;
	unsigned char* buffer = (unsigned char*)malloc(size);

	sample5a(buffer,2,2,3,150);

	FILE* fd = fopen("sample5a.ppm","wb");
	fprintf(fd,"P6\n# CREATOR: unknown\n%d %d\n255\n",width,height);
	fwrite(buffer,1,size,fd);
	fclose(fd);
	free(buffer);
}

struct pixel
{
	int red;
	int green;
	int blue;
};

void sample6a(unsigned char* buffer, int width, int height, pixel p)
{
	for (int y = 0; y < height; ++y)
	{
		for (int x = 0; x < width; ++x)
		{
			*buffer++ = p.red;
			*buffer++ = p.green;
			*buffer++ = p.blue;
		}
	}
}

void sample6a()
{
	int width = 2;
	int height = 2;
	int channels = 3;
	int size = sizeof(unsigned char)*width*height*channels;
	unsigned char* buffer = (unsigned char*)malloc(size);

	pixel p;
	p.red = 0;
	p.green = 0;
	p.blue = 255;

	sample6a(buffer,2,2,p);

	FILE* fd = fopen("sample6a.ppm","wb");
	fprintf(fd,"P6\n# CREATOR: unknown\n%d %d\n255\n",width,height);
	fwrite(buffer,1,size,fd);
	fclose(fd);
	free(buffer);
}

enum {rgb8,rgba8};

void sample7a(unsigned char* buffer, int width, int height, pixel color, int type)
{
	if (type == rgb8)
	{
		sample3a(buffer, width, height, color.red, color.green, color.blue);
	}
	else if (type == rgba8)
	{
		sample4a(buffer, width, height, color.red, color.green, color.blue, 0);
	}
}

void sample7a()
{
	int width = 2;
	int height = 2;
	int channels = 3;
	int size = sizeof(unsigned char)*width*height*channels;
	unsigned char* buffer = (unsigned char*)malloc(size);

	pixel p;
	p.red = 0;
	p.green = 0;
	p.blue = 255;

	sample7a(buffer, width, height, p, rgb8);

	FILE* fd = fopen("sample7a.ppm","wb");
	fprintf(fd,"P6\n# CREATOR: unknown\n%d %d\n255\n",width,height);
	fwrite(buffer,1,size,fd);
	fclose(fd);
	free(buffer);
}

template <typename view_t, typename pixel_t> inline
void sample8a(view_t v, pixel_t pixel)
{
	using namespace boost::gil;

	for (int y = 0; y < v.height(); ++y)
	{
		for (int x = 0; x < v.width(); ++x)
		{
			v(x,y) = pixel;
		}
	}
}

void sample8a()
{
	int width = 2;
	int height = 2;
	int channels = 3;
	int size = sizeof(unsigned char)*width*height*channels;
	unsigned char* buffer = (unsigned char*)malloc(size);

	boost::gil::rgb8_view_t view = boost::gil::interleaved_view(width,height,
		(boost::gil::rgb8_pixel_t*)buffer,width*sizeof(boost::gil::rgb8_pixel_t));
	
	sample8a(view,boost::gil::rgb8_pixel_t(0,0,255));
	
	FILE* fd = fopen("sample8a.ppm","wb");
	fprintf(fd,"P6\n# CREATOR: unknown\n%d %d\n255\n",width,height);
	fwrite(buffer,1,size,fd);
	fclose(fd);
	free(buffer);
}

template <typename view_t>
void sample9a(view_t v, char value)
{
	using namespace boost::gil;

	for (int y = 0; y < v.height(); ++y)
	{
		for (int x = 0; x < v.width(); ++x)
		{
			for (int c = 0; c < num_channels<view_t>::value; ++c)
			{
				v(x,y)[c] = value;
			}
		}
	}
}

void sample9a()
{
	int width = 2;
	int height = 2;
	int channels = 3;
	int size = sizeof(unsigned char)*width*height*channels;
	unsigned char* buffer = (unsigned char*)malloc(size);

	boost::gil::rgb8_view_t view = boost::gil::interleaved_view(width,height,
		(boost::gil::rgb8_pixel_t*)buffer,width*sizeof(boost::gil::rgb8_pixel_t));
	
	sample9a(view,150);
	
	FILE* fd = fopen("sample9a.ppm","wb");
	fprintf(fd,"P6\n# CREATOR: unknown\n%d %d\n255\n",width,height);
	fwrite(buffer,1,size,fd);
	fclose(fd);
	free(buffer);
}

template <typename pixel_t>
struct sample10a_f
{
	pixel_t p;
	sample10a_f(pixel_t p) : p(p) {}

	template <typename view_t>
	void operator()(const view_t& view)
	{
		for (int y = 0; y < view.height(); ++y)
		{
			for (int x = 0; x < view.width(); ++x)
			{
				view(x,y) = p;
			}
		}
	}
};

void sample10a()
{
	int width = 2;
	int height = 2;
	int channels = 3;
	int size = sizeof(unsigned char)*width*height*channels;
	unsigned char* buffer = (unsigned char*)malloc(size);

	boost::gil::rgb8_view_t view = boost::gil::interleaved_view(width,height,
		(boost::gil::rgb8_pixel_t*)buffer,width*sizeof(boost::gil::rgb8_pixel_t));
	
	sample10a_f<boost::gil::rgb8_pixel_t> sample10a(boost::gil::rgb8_pixel_t(0,0,255));
	sample10a(view);
	
	FILE* fd = fopen("sample10a.ppm","wb");
	fprintf(fd,"P6\n# CREATOR: unknown\n%d %d\n255\n",width,height);
	fwrite(buffer,1,size,fd);
	fclose(fd);
	free(buffer);
}

template <typename rgb_t>
struct sample11a_f
{
	template <typename view_t>
	void operator()(const view_t& view)
	{
		typedef typename view_t::value_type pixel_t;
		pixel_t pixel;
		value_type<rgb_t>(pixel);

		for (int y = 0; y < view.height(); ++y)
		{
			for (int x = 0; x < view.width(); ++x)
			{
				view(x,y) = pixel;
			}
		}
	}
};

void sample11a()
{
	int width = 2;
	int height = 2;
	int channels = 3;
	int size = sizeof(unsigned char)*width*height*channels;
	unsigned char* buffer = (unsigned char*)malloc(size);

	boost::gil::rgb8_view_t view = boost::gil::interleaved_view(width,height,
		(boost::gil::rgb8_pixel_t*)buffer,width*sizeof(boost::gil::rgb8_pixel_t));
	
	typedef rgb<0,0,255> blue;
	sample11a_f<blue> f;
	f(view);
	
	FILE* fd = fopen("sample11a.ppm","wb");
	fprintf(fd,"P6\n# CREATOR: unknown\n%d %d\n255\n",width,height);
	fwrite(buffer,1,size,fd);
	fclose(fd);
	free(buffer);
}

template <typename rgb_t>
struct sample12a_f
{
	template <typename view_t>
	void operator()(const view_t& view)
	{
		typedef typename view_t::value_type pixel_t;
		pixel_t pixel;
		value_type<rgb_t>(pixel);

		for (int y = 0; y < view.height(); ++y)
		{
			typename view_t::x_iterator it = view.row_begin(y);
			for (int x = 0; x < view.width(); ++x)
			{
				it[x] = pixel;
			}
		}
	}
};

void sample12a()
{
	int width = 2;
	int height = 2;
	int channels = 3;
	int size = sizeof(unsigned char)*width*height*channels;
	unsigned char* buffer = (unsigned char*)malloc(size);

	boost::gil::rgb8_view_t view = boost::gil::interleaved_view(width,height,
		(boost::gil::rgb8_pixel_t*)buffer,width*sizeof(boost::gil::rgb8_pixel_t));
	
	typedef rgb<0,0,255> blue;
	sample12a_f<blue> f;
	f(view);
	
	FILE* fd = fopen("sample12a.ppm","wb");
	fprintf(fd,"P6\n# CREATOR: unknown\n%d %d\n255\n",width,height);
	fwrite(buffer,1,size,fd);
	fclose(fd);
	free(buffer);
}

template <typename rgb_t>
struct sample13a_f
{
	template <typename view_t>
	void operator()(const view_t& view)
	{
		typedef typename view_t::value_type pixel_t;
		pixel_t pixel;
		value_type<rgb_t>(pixel);

		if (sizeof(pixel_t) == 3 && boost::gil::num_channels<view_t>::value == 3)
		{
			/*
			IppiSize size;
			size.width = view.width();
			size.height = view.height();
			int step = view.width()*sizeof(pixel_t);
			unsigned char* buffer = interleaved_view_get_raw_data(view);
			ippiCopy_8u_C3R(buffer, step, buffer, step, size);	
			*/
		}
		else if (sizeof(pixel_t) == 4 && boost::gil::num_channels<view_t>::value == 4)
		{
			/*
			IppiSize size;
			size.width = view.width();
			size.height = view.height();
			int step = view.width()*sizeof(pixel_t);
			unsigned char* buffer = interleaved_view_get_raw_data(view);
			ippiCopy_8u_C4R(buffer, step, buffer, step, size);	
			*/
		}
		else 
		{
			for (int y = 0; y < view.height(); ++y)
			{
				typename view_t::x_iterator it = view.row_begin(y);
				for (int x = 0; x < view.width(); ++x)
				{
					it[x] = pixel;
				}
			}
		}
	}
};

void sample13a()
{
	int width = 2;
	int height = 2;
	int channels = 3;
	int size = sizeof(unsigned char)*width*height*channels;
	unsigned char* buffer = (unsigned char*)malloc(size);

	boost::gil::rgb8_view_t view = boost::gil::interleaved_view(width,height,
		(boost::gil::rgb8_pixel_t*)buffer,width*sizeof(boost::gil::rgb8_pixel_t));
	
	typedef rgb<0,0,255> blue;
	sample13a_f<blue> f;
	f(view);
	
	FILE* fd = fopen("sample13a.ppm","wb");
	fprintf(fd,"P6\n# CREATOR: unknown\n%d %d\n255\n",width,height);
	fwrite(buffer,1,size,fd);
	fclose(fd);
	free(buffer);
}

template <typename type_t>
struct is_rgb
{
	static const int valid = false;
};

template <typename type_t>
struct is_bgr
{
	static const int valid = false;
};

template<>
struct is_rgb<boost::gil::rgb8_view_t> {static const int valid = true;};

template<>
struct is_bgr<boost::gil::bgr8_view_t> {static const int valid = true;};

void sample14a()
{
	BOOST_STATIC_ASSERT(is_bgr<boost::gil::bgr8_view_t>::valid);
	BOOST_STATIC_ASSERT(is_rgb<boost::gil::rgb8_view_t>::valid);
	BOOST_STATIC_ASSERT(is_rgb<boost::gil::bgr8_view_t>::valid == false);
	BOOST_STATIC_ASSERT(is_bgr<boost::gil::rgb8_view_t>::valid == false);
}

struct sample15a_f
{
	template <typename view_t>
	void operator()(view_t view)
	{
		if (is_rgb<view_t>::valid)
		{
			printf("sample15a_f - hardware optmized rgb8\n");
		}
		else if (is_bgr<view_t>::valid)
		{
			printf("sample15a_f - hardware optmized bgr8\n");
		}
		else 
		{
			printf("sample15a_f - sofware default\n");
		}
	}	
};

void sample15a()
{
	int width = 2;
	int height = 2;
	int channels = 3;
	int size = sizeof(unsigned char)*width*height*channels;
	unsigned char* buffer = (unsigned char*)malloc(size);

	boost::gil::rgb8_view_t view = boost::gil::interleaved_view(width,height,
		(boost::gil::rgb8_pixel_t*)buffer,width*sizeof(boost::gil::rgb8_pixel_t));
		
	sample15a_f func;
	func(view);
}

struct sample16a_f
{
	void operator()(boost::gil::rgb8_view_t view)
	{
		printf("sample16a_f - hardware optmized rgb8\n");
	}
	
	void operator()(boost::gil::bgr8_view_t view)
	{
		printf("sample16a_f - hardware optmized bgr8\n");
	}

	template <typename view_t>
	void operator()(view_t view)
	{
		printf("sample16a_f - sofware default\n");
	}
};

void sample16a()
{
	int width = 2;
	int height = 2;
	int channels = 3;
	int size = sizeof(unsigned char)*width*height*channels;
	unsigned char* buffer = (unsigned char*)malloc(size);

	boost::gil::rgba8_view_t view = boost::gil::interleaved_view(width,height,
		(boost::gil::rgba8_pixel_t*)buffer,width*sizeof(boost::gil::rgba8_pixel_t));

	sample16a_f func;
	func(view);
}

template<bool condition, class Then, class Else>
struct IF
{ 
	typedef Then RET;
};

template<class Then, class Else>
struct IF<false,Then,Else>
{ 
	typedef Else RET;
};

struct sample17a_bgr
{
	void operator()(boost::gil::bgr8_view_t view)
	{
		printf("sample17a - bgr_fill_functor\n");
	}
};

struct sample17a_rgb
{
	void operator()(boost::gil::rgb8_view_t view)
	{
		printf("sample17a - rgb_fill_functor\n");
	}
};

struct sample17a_default
{
	template <typename view_t>
	void operator()(view_t view)
	{
		printf("sample17a - default_fill_functor\n");
	}
};

typedef IF<is_rgb<boost::gil::rgb8_view_t>::valid, sample17a_rgb, sample17a_bgr> functor_t;

void sample17a()
{
	int width = 500;
	int height = 500;
	int channels = 3;
	int size = sizeof(unsigned char)*width*height*channels;
	unsigned char* buffer = (unsigned char*)malloc(size);

	boost::gil::rgb8_view_t view = boost::gil::interleaved_view(width,height,
		(boost::gil::rgb8_pixel_t*)buffer,width*sizeof(boost::gil::rgb8_pixel_t));

	functor_t::RET()(view);

	FILE* fd = fopen("sample17a.ppm","wb");
	fprintf(fd,"P6\n# CREATOR: unknown\n%d %d\n255\n",width,height);
	fwrite(buffer,1,size,fd);
	fclose(fd);
	free(buffer);
}

int main()
{
	sample1a();
	sample2a();
	sample3a();
	sample4a();
	sample5a();
	sample6a();
	sample7a();
	sample8a();
	sample9a();
	sample10a();
	sample11a();
	sample12a();
	sample13a();
	sample14a();
	sample15a();
	sample16a();
	sample17a();
	return 0;
}


